# ternary-contours architectural documentation bundle

This bundle contains documentation-only files for `evnekdev/ternary-contours`.
It records reproducible irregular-mesh ensemble generation as deferred future
work while preserving the current scope of the metrics milestone.

Copy the `docs/` directory into the repository root, preserving paths.
The three existing Markdown files in this bundle are complete replacement
versions based on `master` as reviewed on 2026-08-01. Review the diff before
committing if the repository has moved since then.

Included files:

- `docs/architecture/irregular-mesh-ensemble-roadmap.md` — new roadmap document.
- `docs/knowledge-base/README.md` — adds the roadmap to the knowledge-base index.
- `docs/knowledge-base/irregular/README.md` — records the deferred generator plan.
- `docs/knowledge-base/regular/04_architecture/modular_design.md` — updates the
  architectural dependency graph and future module boundaries.

No Rust implementation, dependency, feature, CI, or release change is included.
