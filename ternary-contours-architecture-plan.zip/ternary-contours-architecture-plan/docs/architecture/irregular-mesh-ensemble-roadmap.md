# Roadmap for reproducible irregular-mesh ensembles

## Status

Deferred architectural work. This document records the intended direction but
is not an implementation commitment for the current metrics milestone.

The current priorities are:

1. define and validate irregular-triangulation metrics;
2. define gradient, Hessian, curvature, and method-response metrics shared by
   regular and irregular scalar fields;
3. use those metrics to characterize existing meshes and numerical methods;
4. only then implement reproducible irregular-mesh ensemble generators.

Mesh generation must consume the metrics subsystem rather than duplicate its
geometry, histogram, or distribution logic.

## Motivation

Comparative interpolation studies need controlled families of irregular meshes,
not only unrelated random point clouds. A useful ensemble should allow one mesh
property to vary while others remain approximately fixed, for example:

- increasing triangle-area dispersion at similar shape quality;
- increasing aspect ratio at similar area distribution;
- changing anisotropy orientation relative to field curvature;
- increasing local size gradation;
- changing boundary sampling density;
- moving from a regular lattice through mild perturbation to strongly irregular
  sampling.

The generator must report both requested and achieved statistics. Shared
vertices, Delaunay connectivity, boundary constraints, and topology prevent
arbitrary triangle statistics from being prescribed independently or matched
exactly in general.

## Scope boundary

Mesh-ensemble generators apply only to irregular meshes and scattered sampling.
They are not required for `RegularTernaryGrid`, whose geometry is deterministic
and analytically known.

The following remain shared between regular and irregular fields:

- constrained ternary gradients and invariant logical gradient norms;
- local Hessian and curvature estimates;
- gradient-jump metrics;
- derived scalar quantities;
- interpolation-error and contour-response metrics.

## Canonical geometry

All generators and targets must use the same equilateral logical embedding as
the irregular mesh and metrics implementations:

```text
A = (0, 0)
B = (1, 0)
C = (1/2, sqrt(3)/2)
```

Public samples remain normalized semantic compositions `(a,b,c)`.

## Target descriptions

A future generator should support targets expressed as distributions, quantiles,
or spatial fields. Candidate targets include:

- triangle area or characteristic size;
- edge length;
- mean-ratio quality;
- radius-ratio quality;
- altitude aspect ratio;
- shape-tensor anisotropy;
- anisotropy orientation;
- adjacent-triangle area ratio;
- vertex density;
- boundary spacing;
- hull-to-interior sample fraction.

Target records must use the metric definitions published by the metrics module.
Do not introduce generator-specific definitions of aspect ratio or triangle
quality.

## Generator families

### Perturbed regular lattice

Start from a regular ternary lattice and perturb interior vertices with a seeded,
bounded displacement. This provides a controlled path from regular to mildly
irregular geometry.

Useful controls include:

- subdivision count;
- perturbation amplitude relative to lattice spacing;
- isotropic or directional perturbation;
- spatially varying amplitude;
- minimum accepted triangle quality;
- random seed.

### Density-driven point sampling

Sample points from a scalar density field in the logical plane and construct a
Delaunay mesh. In two dimensions, a target characteristic spacing `h(x)` is
associated approximately with point density proportional to `1/h(x)^2`.

This family supports:

- uniform random samples;
- log-normal-like size variation;
- clustered and sparse regions;
- radial or directional density gradients;
- mixture distributions;
- boundary-specific sampling policies.

### Minimum-distance sampling

Use Poisson-disk-like or best-candidate sampling to avoid uncontrolled near-
duplicate points and extreme accidental slivers while retaining stochasticity.
The minimum distance may be constant or derived from a sizing field.

### Metric-driven anisotropic sampling

Use a symmetric positive-definite metric tensor field to specify local desired
sizes and directions. A constant metric can initially be implemented by an
affine transformation, isotropic sampling in transformed coordinates, and a
mapping back to the canonical plane.

Spatially varying anisotropic metric generation is explicitly deferred until
simpler families and target-statistics optimization have been validated.

### Target-statistics optimization

Wrap an initial generator with a deterministic seeded optimizer that perturbs,
inserts, removes, or relocates vertices and accepts changes that reduce a target
objective.

A conceptual objective is:

```text
J = w_area * D(area_histogram, area_target)
  + w_shape * D(shape_histogram, shape_target)
  + w_aspect * D(aspect_histogram, aspect_target)
  + w_angle * D(orientation_histogram, orientation_target)
  + w_grade * gradation_penalty
  + w_boundary * boundary_penalty
```

Suitable discrepancies may include quantile error, Wasserstein-like distance,
or another documented deterministic distribution distance.

The optimizer must not promise exact matching when constraints are incompatible.

## Reproducibility

Every stochastic generator must accept an explicit seed and return enough
metadata to reproduce the result:

- generator family and version;
- complete options;
- random seed;
- accepted/rejected attempt counts;
- requested targets;
- achieved metrics;
- final objective or discrepancy;
- stopping condition.

The same crate version, options, and seed should produce deterministic output
within the documented platform and floating-point guarantees.

## Proposed API direction

The following is illustrative and must not be implemented prematurely:

```rust
pub enum IrregularMeshGenerator {
    PerturbedRegular(PerturbedRegularOptions),
    DensitySampled(DensitySamplingOptions),
    MinimumDistance(MinimumDistanceOptions),
    ConstantMetric(ConstantMetricOptions),
}

pub struct MeshDistributionTarget {
    pub triangle_area: Option<TargetDistribution>,
    pub mean_ratio_quality: Option<TargetDistribution>,
    pub altitude_aspect_ratio: Option<TargetDistribution>,
    pub orientation: Option<TargetDistribution>,
    pub adjacent_area_ratio: Option<TargetDistribution>,
}

pub struct GeneratedIrregularMesh {
    pub mesh: IrregularTernaryMesh,
    pub report: MeshGenerationReport,
}
```

The report should reference `IrregularTriangulationMetrics` or its eventual
replacement rather than embedding a parallel summary model.

## Controlled experimental families

Scientific validation should prefer structured ensembles where one factor is
varied at a time:

1. fixed characteristic size with increasing shape distortion;
2. fixed shape-quality envelope with increasing area variation;
3. fixed area distribution with increasing anisotropy;
4. fixed anisotropy with changing orientation relative to an analytic Hessian;
5. increasing local size gradation;
6. increasing boundary sparsity;
7. increasing perturbation away from a regular lattice.

Each family should include multiple seeded replicates. Comparative analysis can
then relate interpolation and contour errors to geometry, curvature, alignment,
and interactions without treating simple correlation as causation.

## Dependency direction

```text
canonical simplex geometry
        ↓
irregular mesh topology
        ↓
irregular triangulation metrics
        ↓
target distributions and discrepancy measures
        ↓
seeded mesh generators
        ↓
optional target-statistics optimizer
        ↓
validation ensembles and comparative studies
```

Generators must not become dependencies of interpolation or contour extraction.
They belong to analysis, testing, examples, or an optional future feature.

## Proposed future module boundary

```text
src/metrics/
    distribution.rs
    irregular.rs
    field.rs
    curvature.rs
    response.rs

src/generation/                 # future, optional
    mod.rs
    perturbed_regular.rs
    density.rs
    minimum_distance.rs
    metric.rs
    optimize.rs
    report.rs
```

A separate crate may be preferable if generation dependencies or optimization
machinery become heavy.

## Validation requirements for a future milestone

A generator milestone should verify:

- exact reproducibility from a seed;
- valid finite normalized compositions;
- no duplicate samples;
- successful Delaunay construction or typed failure;
- requested-versus-achieved metric reports;
- convergence or explicit stopping status;
- controlled one-factor mesh families;
- serialization or CSV-friendly metadata;
- no effect on normal interpolation and contour feature dependencies.

## Explicitly deferred

The current metrics milestone must not implement:

- random mesh generation;
- target histogram optimization;
- adaptive remeshing;
- vertex relocation for quality improvement;
- constrained Delaunay domains;
- holes or non-convex boundaries;
- spatially varying anisotropic metric meshing;
- mesh generation in three or more dimensions.
