# Numerical knowledge base

This directory contains the editable Markdown source for the regular-grid
ternary contour design and the separate irregular-triangulation research note.

- [`regular/README.md`](regular/README.md) describes the implemented regular-grid
  scalar field, cubic-alpha interpolation, contour topology, regularization, and
  projection pipeline.
- [`irregular/README.md`](irregular/README.md) records the irregular roadmap. The
  Delaunay-backed linear fields are implemented behind `irregular-delaunay`;
  self-consistent irregular cubic-alpha point evaluation and irregular isolines
  are implemented behind `irregular-cubic-alpha`. Irregular bands remain deferred.
- [`../numerical-validation.md`](../numerical-validation.md) records the
  maintained deterministic numerical audit, acceptance envelopes, and limits.
- [`../architecture/irregular-mesh-ensemble-roadmap.md`](../architecture/irregular-mesh-ensemble-roadmap.md)
  records the deferred plan for reproducible irregular-mesh ensembles and
  target-distribution generation. It is architectural guidance only and does
  not expand the current metrics milestone.

The repository-level ZIP bundles are retained as archival convenience copies.
They are excluded from Cargo packages; these Markdown files are the maintained,
reviewable source.
