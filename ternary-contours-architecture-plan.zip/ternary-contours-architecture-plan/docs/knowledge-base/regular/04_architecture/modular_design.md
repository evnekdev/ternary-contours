# Modular Architecture

## Immediate module boundaries

Suggested structure inside the current crate:

```text
src/contour/
    mod.rs
    regular_grid.rs
    linear.rs
    topology.rs
    paths.rs
    regularize.rs
    project.rs
    render.rs

src/interpolation/
    mod.rs
    alpha_interval.rs
    line_family.rs
    cubic_triangle.rs
    extrapolation.rs
```

Exact filenames may differ, but preserve these conceptual boundaries.

The analytical metrics layer should remain separate from field construction and
contour extraction:

```text
src/metrics/
    mod.rs
    distribution.rs
    gradient.rs
    curvature.rs
    field.rs
    response.rs
    regular.rs
    irregular.rs
```

Shared gradient, Hessian, curvature, and method-response concepts belong in the
common metrics modules. Delaunay triangle quality, valence, hull, density, and
gradation metrics belong only in `metrics::irregular`.

## Dependency direction

```text
regular grid/indexing or irregular mesh topology
        ↓
1-D interval preparation where selected
        ↓
local interpolation field
        ↓
contour topology extraction
        ↓
path regularization/projection
        ↓
immutable numerical results
        ↓
Plotters rendering adapter
```

The metrics layer observes grids, meshes, prepared fields, and final numerical
results without becoming a prerequisite for ordinary interpolation or contour
construction.

A future irregular-mesh generation layer may depend on canonical geometry,
irregular topology, and irregular metrics:

```text
canonical simplex geometry
        ↓
irregular mesh topology
        ↓
irregular triangulation metrics
        ↓
future seeded mesh generators and target matching
```

The reverse dependency is forbidden: interpolation and contour extraction must
not depend on random mesh generators or optimization machinery.

The numerical layers must not depend on:

- Plotters backends;
- drawing areas;
- chart orientation;
- screen coordinates;
- legends;
- SVG or PNG details.

## Suggested core traits

A future extraction can center around a small field interface:

```rust
pub trait LocalSimplexField<const D: usize> {
    fn value(&self, barycentric: &[f64; D + 1]) -> f64;
    fn gradient_reduced(&self, reduced: &[f64; D]) -> [f64; D];
}
```

Rust stable const-generics may require a different representation for `D+1`; do not force this exact syntax prematurely. The conceptual interface matters more than the initial type signature.

For the current 2-D implementation, concrete optimized types are acceptable.

## Top-level interpolation API

```rust
pub enum ContourInterpolation {
    Linear,
    CubicAlpha(CubicAlphaOptions),
}

pub enum CubicAlphaMethod {
    Akima,
    Makima,
    Pchip,
    Steffen,
}

pub enum BinaryExtrapolation {
    Muggianu,
    Kohler,
}
```

Keep interpolation order separate from extrapolation geometry.

## Metrics boundary

The regular grid is a deterministic controlled geometry. It does not require a
public Delaunay-style triangle-quality API.

The following are irregular-only:

- triangle-size and quality distributions;
- irregular edge-length and gradation distributions;
- Delaunay valence and hull topology;
- sample-density and boundary-distance metrics.

The following apply to both regular and irregular fields:

- constrained ternary gradients;
- invariant logical gradient norms;
- local Hessian and curvature estimates;
- one-sided gradient jumps;
- derived scalar quantities;
- interpolation and contour response metrics.

## Deferred irregular-mesh generation

Reproducible random and target-statistics mesh generation is a future analysis
capability, not part of the current metrics milestone.

Its architectural plan is maintained in:

```text
docs/architecture/irregular-mesh-ensemble-roadmap.md
```

The future layer may support perturbed regular samples, density-driven sampling,
minimum-distance sampling, constant anisotropic metrics, and target-statistics
optimization. It must use the published irregular metrics definitions and
return requested-versus-achieved reports.

If generator dependencies become substantial, prefer an optional feature or a
separate crate rather than expanding the default numerical core.

## Future crate split

Likely eventual arrangement:

```text
simplex-field-core
    alpha intervals
    local simplex fields
    contour topology
    regularization/projection
    shared derivative and response metrics

ternary-contours
    regular ternary grid
    irregular Delaunay specialization
    2-D triangular metrics

ternary-mesh-ensembles          # possible future crate
    seeded irregular sample generation
    target-distribution optimization
    reproducible ensemble reports

plotters-ternary
    plotting adapter and chart integration

simplex-contours-nd
    N-component/Kuhn-simplex grids
```

## Cross-language architecture

After the core API stabilizes:

```text
Rust numerical core
    ↓ stable C ABI
Python / MATLAB MEX / Fortran ISO_C_BINDING
```

Use flat result arrays across the ABI:

```text
levels
path_level_indices
path_offsets
path_closed
points_barycentric
```

Do not expose Rust `Vec`, Rust enums without explicit representation, or Rust-owned strings through the ABI.
